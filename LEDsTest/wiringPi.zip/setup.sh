mv ./libwiringPi.so /usr/lib
chmod 755 /usr/lib/libwiringPi.so
ldconfig
